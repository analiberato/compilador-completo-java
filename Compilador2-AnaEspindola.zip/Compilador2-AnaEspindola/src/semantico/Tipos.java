package semantico;

/**
 *
 * Objeto que armazena: Instru��o, operando1, operando2
 * para a tabela de instru��es
 *
 */
class Tipos
{
	public int codigo;
	public int op1;
	public int op2;

	Tipos()
	{
		this.codigo = 0;
		this.op1 = 0;
		this.op2 = 0;
	}
}