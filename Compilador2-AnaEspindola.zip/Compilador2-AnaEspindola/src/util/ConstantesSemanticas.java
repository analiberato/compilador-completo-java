package util;

import java.util.HashMap;
import java.util.Map;

public class ConstantesSemanticas {
	public static final Map<String, Integer> ACOES_SEMANTICAS = new HashMap<String, Integer>();

	static {
	ACOES_SEMANTICAS.put("#100", Integer.valueOf(100));
	ACOES_SEMANTICAS.put("#101", Integer.valueOf(101));
	ACOES_SEMANTICAS.put("#102", Integer.valueOf(102));
	ACOES_SEMANTICAS.put("#103", Integer.valueOf(103));
	ACOES_SEMANTICAS.put("#104", Integer.valueOf(104));
	ACOES_SEMANTICAS.put("#105", Integer.valueOf(105));
	ACOES_SEMANTICAS.put("#106", Integer.valueOf(106));
	ACOES_SEMANTICAS.put("#107", Integer.valueOf(107));
	ACOES_SEMANTICAS.put("#108", Integer.valueOf(108));
	ACOES_SEMANTICAS.put("#109", Integer.valueOf(109));
	ACOES_SEMANTICAS.put("#110", Integer.valueOf(110));
	ACOES_SEMANTICAS.put("#111", Integer.valueOf(111));
	ACOES_SEMANTICAS.put("#112", Integer.valueOf(112));
	ACOES_SEMANTICAS.put("#113", Integer.valueOf(113));
	ACOES_SEMANTICAS.put("#114", Integer.valueOf(114));
	ACOES_SEMANTICAS.put("#115", Integer.valueOf(115));
	ACOES_SEMANTICAS.put("#116", Integer.valueOf(116));
	ACOES_SEMANTICAS.put("#117", Integer.valueOf(117));
	ACOES_SEMANTICAS.put("#118", Integer.valueOf(118));
	ACOES_SEMANTICAS.put("#119", Integer.valueOf(119));
	ACOES_SEMANTICAS.put("#120", Integer.valueOf(120));
	ACOES_SEMANTICAS.put("#121", Integer.valueOf(121));
	ACOES_SEMANTICAS.put("#122", Integer.valueOf(122));
	ACOES_SEMANTICAS.put("#123", Integer.valueOf(123));
	ACOES_SEMANTICAS.put("#124", Integer.valueOf(124));
	ACOES_SEMANTICAS.put("#125", Integer.valueOf(125));
	ACOES_SEMANTICAS.put("#126", Integer.valueOf(126));
	ACOES_SEMANTICAS.put("#127", Integer.valueOf(127));
	ACOES_SEMANTICAS.put("#128", Integer.valueOf(128));
	ACOES_SEMANTICAS.put("#129", Integer.valueOf(129));
	ACOES_SEMANTICAS.put("#130", Integer.valueOf(130));
	ACOES_SEMANTICAS.put("#131", Integer.valueOf(131));
	ACOES_SEMANTICAS.put("#132", Integer.valueOf(132));
	ACOES_SEMANTICAS.put("#133", Integer.valueOf(133));
	ACOES_SEMANTICAS.put("#134", Integer.valueOf(134));
	ACOES_SEMANTICAS.put("#135", Integer.valueOf(135));
	ACOES_SEMANTICAS.put("#136", Integer.valueOf(136));
	ACOES_SEMANTICAS.put("#137", Integer.valueOf(137));
	ACOES_SEMANTICAS.put("#138", Integer.valueOf(138));
	ACOES_SEMANTICAS.put("#139", Integer.valueOf(139));
	ACOES_SEMANTICAS.put("#140", Integer.valueOf(140));
	ACOES_SEMANTICAS.put("#141", Integer.valueOf(141));
	ACOES_SEMANTICAS.put("#142", Integer.valueOf(142));
	ACOES_SEMANTICAS.put("#143", Integer.valueOf(143));
	ACOES_SEMANTICAS.put("#144", Integer.valueOf(144));
	ACOES_SEMANTICAS.put("#145", Integer.valueOf(145));
	ACOES_SEMANTICAS.put("#146", Integer.valueOf(146));
	ACOES_SEMANTICAS.put("#147", Integer.valueOf(147));
	ACOES_SEMANTICAS.put("#148", Integer.valueOf(148));
	ACOES_SEMANTICAS.put("#149", Integer.valueOf(149));
	ACOES_SEMANTICAS.put("#150", Integer.valueOf(150));
	ACOES_SEMANTICAS.put("#151", Integer.valueOf(151));
	ACOES_SEMANTICAS.put("#152", Integer.valueOf(152));
	ACOES_SEMANTICAS.put("#153", Integer.valueOf(153));
	ACOES_SEMANTICAS.put("#154", Integer.valueOf(154));
	ACOES_SEMANTICAS.put("#155", Integer.valueOf(155));
	ACOES_SEMANTICAS.put("#156", Integer.valueOf(156));

	}
}